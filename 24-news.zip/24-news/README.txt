
TITLE: 
24 News - 100% Fully Responsive Free HTML5 Bootstrap Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Font Awesome
http://fontawesome.io

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

Stellar Parallax
http://markdalgleish.com/projects/stellar.js/

Google Maps
https://maps.google.com

Demo Images:
http://unsplash.com

